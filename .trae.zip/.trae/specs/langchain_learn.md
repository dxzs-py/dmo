# LangChain Documentation

## Documentation Index
Fetch the complete documentation index at: /llms.txt
Use this file to discover all available pages before exploring further.

In the Learn section of the documentation, you’ll find a collection of tutorials, conceptual overviews, and additional resources to help you build powerful applications with LangChain and LangGraph.

## Use cases
Below are tutorials for common use cases, organized by framework.

### Deep Agents
Deep Agents include built-in functionality for managing context, a virtual filesystem, and other common agent requirements.
- **Data analysis**: Build a data analysis agent that sends reports to Slack.
- **Deep research**: Build a multi-step web research agent with subagent delegation and strategic reflection.

### LangChain
LangChain agent implementations make it easy to get started for simple use cases.
- **Semantic Search**: Build a semantic search engine over a PDF with LangChain components.
- **RAG Agent**: Create a Retrieval Augmented Generation (RAG) agent.
- **SQL Agent**: Build a SQL agent to interact with databases with human-in-the-loop review.
- **Voice Agent**: Build an agent you can speak and listen to.

### LangGraph
LangChain’s agent implementations use LangGraph primitives.
If deeper customization is required, agents can be implemented directly in LangGraph.
- **Custom RAG Agent**: Build a RAG agent using LangGraph primitives for fine-grained control.
- **Custom SQL Agent**: Implement a SQL agent directly in LangGraph for maximum flexibility.

### Multi-agent
These tutorials demonstrate multi-agent patterns, blending LangChain agents with LangGraph workflows.
- **Subagents: Personal assistant**: Build a personal assistant that delegates to sub-agents.
- **Handoffs: Customer support**: Build a customer support workflow where a single agent transitions between different states.
- **Router: Knowledge base**: Build a multi-source knowledge base that routes queries to specialized agents.
- **Skills: SQL assistant**: Build an agent that loads specialized skills progressively using on-demand context loading.

## Conceptual overviews
These guides explain the core concepts and APIs underlying LangChain and LangGraph.
- **Memory**: Understand persistence of interactions within and across threads.
- **Context engineering**: Learn methods for providing AI applications the right information and tools to accomplish a task.
- **Graph API**: Explore LangGraph’s declarative graph-building API.
- **Functional API**: Build agents as a single function.

## Additional resources
- **LangChain Academy**: Courses and exercises to level up your LangChain skills.
- **Case Studies**: See how teams are using LangChain and LangGraph in production.